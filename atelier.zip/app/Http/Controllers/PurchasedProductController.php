<?php

namespace App\Http\Controllers;

use App\Models\PurchasedProduct;
use App\Models\Purchase;
use App\Models\Product;
use App\Models\UserShiksho;
use App\Models\CustomerPhone;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Customer;
use App\Tools\SmsTools;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Morilog\Jalali\Jalalian;


class PurchasedProductController extends Controller
{
    public function index(Request $request)
{
    // فقط Purchase هایی که:
    // 1. cart_id ندارند (فروش فیزیکی مستقیم)
    // 2. یا cart_id دارند و Cart status آن‌ها shipped است
    $query = Purchase::with('purchasedProducts.product')
        ->where(function($q) {
            $q->whereNull('cart_id') // فروش فیزیکی
              ->orWhereHas('cart', function($cartQuery) {
                  $cartQuery->where('status', Cart::STATUS_SHIPPED); // سفارش اینترنتی که shipped شده
              });
        })
        ->orderBy('id', 'desc');

    // جستجو بر اساس searchFilterModel
    $searchDataModel = json_decode($request->input('searchFilterModel'));
    if ($searchDataModel) {
        $query->where(function($q) use ($searchDataModel) {
            if (is_object($searchDataModel)) {
                // جستجو بر اساس شماره تلفن
                if (isset($searchDataModel->phone)) {
                    $q->where('phone', 'like', '%' . $searchDataModel->phone . '%');
                }
            } else if (is_string($searchDataModel)) {
                // اگر یک رشته ساده بود، در شماره تلفن جستجو می‌کند
                $q->where('phone', 'like', '%' . $searchDataModel . '%');
            }
        });
    }

    // فیلتر تاریخ
    if ($request->has('filter')) {
        if ($request->filter === 'today') {
            $query->whereDate('created_at', Carbon::today());
        } elseif ($request->filter === 'week') {
            // فیلتر هفته شمسی (شنبه تا جمعه)
            $now = Jalalian::now();
            $dayOfWeek = $now->getDayOfWeek(); // 0 = شنبه, 6 = جمعه
            $startOfWeek = Jalalian::now()->subDays($dayOfWeek)->toCarbon()->startOfDay();
            $endOfWeek = Jalalian::now()->addDays(6 - $dayOfWeek)->toCarbon()->endOfDay();
            $query->whereBetween('created_at', [$startOfWeek, $endOfWeek]);
        } elseif ($request->filter === 'month') {
            $query->whereMonth('created_at', Carbon::now()->month)
                  ->whereYear('created_at', Carbon::now()->year);
        } elseif ($request->filter === 'range') {
            // فیلتر بازه تاریخ شمسی
            if ($request->has('from_date')) {
                $fromDate = json_decode($request->input('from_date'));
                $fromCarbon = (new Jalalian($fromDate->year, $fromDate->month, $fromDate->day))->toCarbon()->startOfDay();
                $query->where('created_at', '>=', $fromCarbon);
            }
            if ($request->has('to_date')) {
                $toDate = json_decode($request->input('to_date'));
                $toCarbon = (new Jalalian($toDate->year, $toDate->month, $toDate->day))->toCarbon()->endOfDay();
                $query->where('created_at', '<=', $toCarbon);
            }
        }
    }

    $items = $query->paginate();

    // محاسبه مجموع قیمت خرید برای آیتم‌های این صفحه
    $total = Purchase::whereIn('id', $items->pluck('id'))
        ->select(DB::raw('SUM(total_amount) as total'))
        ->value('total');

    // اضافه کردن به meta به شکل درست
    $items->withPath(url()->current()); // حفظ مسیر URL

    // اضافه کردن custom meta
    $itemsArray = $items->toArray();
    $itemsArray['total_purchase_price'] = $total;

    return response($itemsArray, 200);
}


    public function store(Request $request)
    {
        $request->validate([
            'phone' => 'nullable|string|digits:11',
            'products' => 'required|array|min:1',
            'products.*.product_id' => 'required|exists:products,id',
            'products.*.quantity' => 'required|integer|min:1',
            'products.*.sale_price' => 'nullable|numeric|min:0', // قیمت فروش با تخفیف (اختیاری)
            'products.*.discount_percent' => 'nullable|numeric|min:0|max:100', // درصد تخفیف (اختیاری)
            'products.*.size' => 'nullable|string|max:255', // سایز انتخاب شده (اختیاری)
            'products.*.color' => 'nullable|string|max:255', // رنگ انتخاب شده (اختیاری)
            'use_credit' => 'nullable|boolean', // آیا کاربر می‌خواهد از اعتبارش استفاده کند؟
            'discount_amount' => 'nullable|numeric|min:0', // مبلغ تخفیف مستقیم (اختیاری)
        ]);

        $phone = $request->input('phone');
        $useCredit = $request->input('use_credit', false);
        
        // خواندن همه محصولات در یک query
        $productIds = array_column($request->input('products'), 'product_id');
        $products = Product::whereIn('id', $productIds)->get()->keyBy('id');
        
        // بررسی موجودی محصولات قبل از ثبت خرید
        foreach ($request->input('products') as $productData) {
            $product = $products->get($productData['product_id']);
            if (!$product) {
                return response(['error' => 'محصول یافت نشد'], 404);
            }
            
            $requestedQuantity = $productData['quantity'];
            if ($product->quantity < $requestedQuantity) {
                return response([
                    'error' => "موجودی محصول '{$product->name}' کافی نیست. موجودی: {$product->quantity}، درخواستی: {$requestedQuantity}"
                ], 400);
            }
        }
        
        // محاسبه مجموع مبلغ خرید بر اساس sale_price (با در نظر گیری تخفیف)
        $originalTotalAmount = 0;
        $productsData = [];
        foreach ($request->input('products') as $productData) {
            $product = $products->get($productData['product_id']);
            
            // تعیین قیمت فروش: اگر sale_price ارسال شده از آن استفاده کن، در غیر این صورت از product.sale_price
            // یا اگر discount_percent داده شده، درصد تخفیف را اعمال کن
            $baseSalePrice = $product->sale_price;
            $quantity = $productData['quantity'];
            
            if (isset($productData['sale_price']) && $productData['sale_price'] !== null) {
                // اگر sale_price مستقیم داده شده
                $salePrice = $productData['sale_price'];
            } elseif (isset($productData['discount_percent']) && $productData['discount_percent'] > 0) {
                // اگر discount_percent داده شده
                $discountAmount = ($baseSalePrice * $productData['discount_percent']) / 100;
                $priceAfterDiscount = max(0, $baseSalePrice - $discountAmount);
                
                // رند کردن به عدد فرد که سه رقم آخرش 0 باشد
                $salePrice = $this->roundToOddWithZeroEnding($priceAfterDiscount);
            } else {
                // بدون تخفیف
                $salePrice = $baseSalePrice;
            }
            
            $originalTotalAmount += $quantity * $salePrice;
            
            // ذخیره اطلاعات محصول برای استفاده بعدی
            $productsData[] = [
                'product_id' => $productData['product_id'],
                'quantity' => $quantity,
                'sale_price' => $salePrice, // قیمت واقعی فروش (با تخفیف)
                'purchase_price' => $product->purchase_price, // برای ذخیره در purchased_products
                'size' => $productData['size'] ?? null, // سایز انتخاب شده
                'color' => $productData['color'] ?? null, // رنگ انتخاب شده
            ];
        }

        // دریافت مبلغ تخفیف مستقیم (اگر وجود داشته باشد)
        $discountAmount = $request->input('discount_amount', 0);
        if ($discountAmount < 0) {
            $discountAmount = 0;
        }
        
        // کسر مبلغ تخفیف از قیمت کل
        $totalAmount = max(0, $originalTotalAmount - $discountAmount);
        $creditUsed = 0;
        $userShiksho = null;

        // اگر شماره تلفن وجود دارد و کاربر می‌خواهد از اعتبار استفاده کند
        if ($phone && $useCredit) {
            $userShiksho = UserShiksho::where('phone', $phone)->first();
            if ($userShiksho && $userShiksho->credit > 0) {
                // استفاده از اعتبار (تا حداکثر مبلغ خرید بعد از تخفیف)
                $creditUsed = min($userShiksho->credit, $totalAmount);
                $userShiksho->useCredit($creditUsed);
                // مبلغ نهایی بعد از کسر اعتبار
                $totalAmount = $totalAmount - $creditUsed;
            }
        }

        $creditEarned = 0;
        
        // اگر تخفیف مستقیم داده نشده باشد و شماره تلفن وجود دارد و اعتبار فعال است، اعتبار جدید را محاسبه کن
        // اگر discount_amount > 0 باشد، اعتبار اضافه نمی‌شود
        $enableLoyaltyCredit = \App\Models\Setting::isEnabled('enable_loyalty_credit', true);
        if ($phone && $enableLoyaltyCredit && $discountAmount == 0) {
            // محاسبه اعتبار کسب شده (بر اساس مبلغ اصلی خرید، قبل از کسر اعتبار استفاده شده)
            $creditEarned = UserShiksho::calculateCredit($originalTotalAmount);
        }

        // ایجاد سبد خرید (Purchase)
        $purchase = Purchase::create([
            'phone' => $phone,
            'total_amount' => $totalAmount,
            'credit_used' => $creditUsed,
            'credit_earned' => $creditEarned,
        ]);

        // ذخیره محصولات خریداری شده و لینک کردن به سبد خرید
        $purchasedProducts = [];
        foreach ($productsData as $productData) {
            $purchasedProducts[] = PurchasedProduct::create([
                'purchase_id' => $purchase->id,
                'product_id' => $productData['product_id'],
                'quantity' => $productData['quantity'],
                'purchase_price' => $productData['purchase_price'], // قیمت خرید محصول برای ثبت
                'sale_price' => $productData['sale_price'], // قیمت واقعی فروش (با تخفیف)
                'size' => $productData['size'] ?? null, // سایز انتخاب شده
                'color' => $productData['color'] ?? null, // رنگ انتخاب شده
            ]);
        }

        // کسر موجودی محصولات بعد از ثبت خرید
        foreach ($productsData as $productData) {
            $product = $products->get($productData['product_id']);
            $product->decrement('quantity', $productData['quantity']);
        }

        // اگر شماره تلفن وجود دارد
        if ($phone) {
            $enableLoyaltyCredit = \App\Models\Setting::isEnabled('enable_loyalty_credit', true);
            
            if ($enableLoyaltyCredit && $creditEarned > 0) {
                // به‌روزرسانی اعتبار (اعتبار قبلی صفر می‌شود و اعتبار جدید اضافه می‌شود)
                UserShiksho::updateCredit($phone, $creditEarned);

                // ارسال پیامک بعد از ذخیره خرید (فقط اگر اعتبار کسب شده باشد)
                $creditFormatted = number_format($creditEarned, 0);
                $text = "شیک شو\nهمراه عزیز مبلغ {$creditFormatted} تومان به اعتبار شما برای خرید بعدی اضافه شد";
                SmsTools::sendShopSms($phone, $text, (string) $purchase->id, $creditEarned, 'credit');
            } else {
                // اگر اعتبار غیرفعال باشد یا اعتبار کسب نشده باشد (به دلیل تخفیف)، فقط پیام ساده بفرست
                $text = "شیکشو\nبا تشکر از خرید شما";
                SmsTools::sendShopSms($phone, $text, (string) $purchase->id, null, 'purchase');
            }

            // ثبت شماره تلفن در جدول customer_phones
            CustomerPhone::createNewPhone($phone);
        }

        // برگرداندن سبد خرید با محصولاتش
        $purchase->load('purchasedProducts.product');
        
        return response($purchase, 201);
    }

    public function show(Purchase $purchase)
    {
        return response($purchase->load('purchasedProducts.product'), 200);
    }

    public function update(Request $request, Purchase $purchase)
    {
        $request->validate([
            'phone' => 'sometimes|nullable|string|digits:11',
            'total_amount' => 'sometimes|required|numeric|min:0',
            'credit_used' => 'sometimes|required|numeric|min:0',
            'credit_earned' => 'sometimes|required|numeric|min:0',
        ]);

        $purchase->update($request->only(['phone', 'total_amount', 'credit_used', 'credit_earned']));

        return response($purchase->load('purchasedProducts.product'), 200);
    }

    public function destroy(Purchase $purchase)
    {
        $purchase->delete();
        return response(['message' => 'سبد خرید حذف شد'], 200);
    }

    /**
     * رند کردن به عدد فرد که دهگان و صدگانش 0 باشد
     * مثال: 130.5 -> 101, 1300 -> 1301, 1450 -> 1501
     * 
     * @param float $number
     * @return float
     */
  

     private function roundToOddWithZeroEnding($number)
     {
         if ($number <= 0) {
             return 0;
         }
     
         $baseThousand = floor($number / 1000);
     
         // اگر زوج بود، یکی کم کن تا فرد شود
         if ($baseThousand % 2 === 0) {
             $lowerOdd = $baseThousand - 1;
         } else {
             $lowerOdd = $baseThousand;
         }
     
         // فرد بعدی
         $upperOdd = $lowerOdd + 2;
     
         $lowerValue = $lowerOdd * 1000;
         $upperValue = $upperOdd * 1000;
     
         // انتخاب نزدیک‌ترین
         return (abs($number - $lowerValue) <= abs($number - $upperValue))
             ? $lowerValue
             : $upperValue;
     }
     





    /**
     * برگشت یک محصول از یک خرید
     * محصول از لیست خرید حذف شده و موجودی برگردانده می‌شود
     * 
     * @param Purchase $purchase
     * @param PurchasedProduct $purchasedProduct
     * @return \Illuminate\Http\Response
     */
    public function returnItem(Purchase $purchase, PurchasedProduct $purchasedProduct)
    {
        // بررسی اینکه محصول متعلق به این خرید باشد
        if ($purchasedProduct->purchase_id !== $purchase->id) {
            return response(['error' => 'این محصول متعلق به این خرید نیست'], 400);
        }

        // افزایش موجودی محصول
        $product = $purchasedProduct->product;
        $product->increment('quantity', $purchasedProduct->quantity);

        // کم کردن مبلغ از total_amount خرید
        $returnAmount = $purchasedProduct->sale_price * $purchasedProduct->quantity;
        $purchase->total_amount = max(0, $purchase->total_amount - $returnAmount);

        // برگشت اعتبار کسب شده متناسب با مبلغ برگشتی
        $creditReturned = 0;
        if ($purchase->credit_earned > 0 && $purchase->phone) {
            // محاسبه اعتبار برگشتی بر اساس نسبت مبلغ برگشتی
            $creditReturned = UserShiksho::calculateCredit($returnAmount);
            
            // کم کردن از credit_earned خرید
            $purchase->credit_earned = max(0, $purchase->credit_earned - $creditReturned);
            
            // کم کردن از اعتبار کاربر
            $userShiksho = UserShiksho::where('phone', $purchase->phone)->first();
            if ($userShiksho && $userShiksho->credit >= $creditReturned) {
                $userShiksho->credit = max(0, $userShiksho->credit - $creditReturned);
                $userShiksho->save();
            }
        }

        $purchase->save();

        // ذخیره اطلاعات برای پاسخ قبل از حذف
        $returnedInfo = [
            'product_id' => $purchasedProduct->product_id,
            'product_name' => $product->name,
            'quantity' => $purchasedProduct->quantity,
            'sale_price' => $purchasedProduct->sale_price,
            'return_amount' => $returnAmount,
            'credit_returned' => $creditReturned,
        ];

        // حذف محصول از لیست خرید
        $purchasedProduct->delete();

        // بارگذاری مجدد خرید با محصولات باقیمانده
        $purchase->load('purchasedProducts.product');

        return response([
            'message' => 'محصول با موفقیت برگشت داده شد',
            'returned_item' => $returnedInfo,
            'purchase' => $purchase,
        ], 200);
    }

    /**
     * دریافت اعتبار کاربر بر اساس شماره تلفن
     * 
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function getCreditByPhone(Request $request)
    {
        $request->validate([
            'phone' => 'required|string|digits:11',
        ]);

        $phone = $request->input('phone');
        $userShiksho = UserShiksho::where('phone', $phone)->first();

        $credit = $userShiksho ? $userShiksho->credit : 0;

        return response([
            'phone' => $phone,
            'use_credit' => $credit,
            'credit' => $credit,
        ], 200);
    }
}
